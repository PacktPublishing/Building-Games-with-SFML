#include "Game.hpp"

int main()
{
	
	Game pacWoman;
	pacWoman.run();
	
	return EXIT_SUCCESS;
		
}
