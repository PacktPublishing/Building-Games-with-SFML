Pac-Woman
=========
Control Pac-Man's wife in a gigantic maze

Author
------
Jonathan

How-to-compile
--------------
Use Cmake, It's easy.
