#include "Game.hpp"
#include <SFML/Graphics.hpp>
int main()
{
	
	Game pacWoman;
	pacWoman.run();
	
	return EXIT_SUCCESS;
		
}
