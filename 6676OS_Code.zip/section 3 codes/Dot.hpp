#ifndef PACWOMAN_DOT_HPP
#define PACWOMAN_DOT_HPP

#include <SFML/Graphics.hpp>

sf::CircleShape getDot();
sf::CircleShape getSuperDot();

#endif // PACWOMAN_DOT_HPP
